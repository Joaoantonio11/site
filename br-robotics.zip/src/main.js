import './style.css'
const ic = p => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`
const I = {
  phone: ic('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>'),
  wa: ic('<path d="M3 21l1.6-4.6A9 9 0 1112 21a9 9 0 01-4.4-1.2z"/>'),
  mail: ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
  user: ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>'),
  userOk: ic('<circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0114 0M16 11l2 2 4-4"/>'),
  globe: ic('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 010 18M12 3a14 14 0 000 18"/>'),
  screen: ic('<rect x="3" y="4" width="18" height="12" rx="1"/><path d="M8 21h8M12 16v5"/>'),
  doc: ic('<path d="M6 3h8l4 4v14H6zM14 3v4h4"/>'),
  pin: ic('<path d="M12 21s7-6.2 7-11a7 7 0 10-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>')
}
const NAV = [['servicos', 'Serviços e peças'], ['em-alta', 'Em alta'], ['sobre', 'Sobre nós'], ['solucoes', 'Soluções']]
const img = n => `/images/${n}.jpg`

const header = () => `<header class="top"><a class="logo" href="#/">BRR</a>
<span>${I.phone} +55 (41) 0103-2010</span>
<a href="https://wa.me/554101032010" target="_blank" rel="noopener">${I.wa} Conversar agora</a>
<a href="mailto:info@brRobotics.com.br">${I.mail} info@brRobotics.com.br</a>
<a class="btn-y" href="#/orcamento">Orçamentos</a></header>`

const hero = (cls, cur, inner, brand = '') => `<section class="hero ${cls}"><div class="hero-nav">${brand}<nav>${NAV.map(([k, t]) =>
  `<a href="#/${k}" ${k === cur ? 'aria-current="page"' : ''}>${t}</a>`).join('')}</nav></div><div class="hero-t">${inner}</div></section>`

const band = (cls, body, pic, alt) => `<article class="band ${cls}"><div class="band-t">${body}</div><img src="${img(pic)}" alt="${alt}"/></article>`

const products = [
  { pic: 'robo-carga', cod: 'ER8-0103-CW', tipo: 'carregar', inst: 'Piso/Teto', rows: ['6', 'IP54', 'Piso', '2800mm', '700kg', '2930kg'] },
  { pic: 'robo-solda', cod: 'ER8-2000-CW', tipo: 'solda', inst: 'Piso/Teto', rows: ['6', 'IP54', 'Piso/Teto', '2800mm', '8kg', '281kg'] }
]
const labels = ['Número de eixos:', 'Grau de proteção IP:', 'Instalação:', 'Alcance do braço:', 'Carga máxima:', 'Peso do corpo:']

const pages = {
  '': () => hero('h-home', '', `<span class="badge-y sm">Equipamentos Industriais</span><h1>Máquinas industriais para a indústria automobilística</h1>
<p>Instalação, treinamento, assistência técnica e fornecimento de peças originais. Pós-venda completo com a qualidade BR Robotics.</p>`, '<strong class="brand">BR Robotics</strong>') + `
<section class="wrap intro"><small>Máquinas</small><h2>Robôs Industriais</h2>
<p>A nova era de Robôs Industriais chega ao Brasil, e a BR Robotics fornece os equipamentos completos para você.</p>
<div class="cats">${[['robo-carga', 'Robôs industriais'], ['robo-palet', 'Robôs de paletização'], ['robo-solda', 'Robôs de solda']].map(([p, t]) =>
    `<a class="cat" href="#/em-alta"><img src="${img(p)}" alt="${t}"/><span>${t}</span></a>`).join('')}</div></section>`,

  servicos: () => hero('h-serv', 'servicos', '<h1 class="one">Serviços Técnicos e peças de alta qualidade</h1>') + `<section class="wrap bands">
${band('b1', `<h2 class="y">Atendimento<br>Pós-venda completo,<br>com a excelência BR Robotics</h2><p>Mais do que vender máquinas, a BR Robotics oferece suporte técnico essencial, garantindo que cada equipamento entregue o máximo de sua performance ao longo dos anos.</p>`, 'atendimento', 'Técnico sorrindo de capacete')}
${band('b2 rev', `<h2>Fornecimento de peças de reposição</h2><p>Aqui na BR Robotics temos peças originais para você manter seu equipamento sempre no padrão correto</p><a class="btn-w" href="#/orcamento">Cotar peças de reposição</a>`, 'pecas', 'Operário manuseando peça')}
${band('b3', `<h2>Entrega de robôs industriais</h2><p>A BR Robotics tem os melhores robôs que a industria pode oferecer para o seu negócio florescer</p><a class="btn-w" href="#/orcamento">Solicitar entrega</a>`, 'robo-solda', 'Robô de solda amarelo')}</section>`,

  'em-alta': () => hero('h-alta', 'em-alta', '<h1 class="one c">Produtos em alta</h1>') + `<section class="wrap prods">${products.map(p => `
<article class="prod"><div class="prod-top"><img src="${img(p.pic)}" alt="${p.cod}"/><div><h3>Descrição do produto:</h3>
<p>${p.cod} é um robô de ${p.tipo} com 6 eixos, carga máxima de 8kg, alcance de 2010mm. Instalação: ${p.inst}.</p><h3>Características Técnicas:</h3></div></div>
<dl class="specs">${labels.map((l, i) => `<dt>${l}</dt><dd>${p.rows[i]}</dd>`).join('')}<dt>Segmentos:</dt><dd>Indústria Metalúrgica, Indústria Metalmecânica</dd></dl></article>`).join('')}</section>`,

  sobre: () => hero('h-sobre', 'sobre', '<small>Sobre nós</small><h1>Sobre a BR Robotics</h1><p>Desde 2000, a BR Robotics existe para atender o seu negócio na Indústria.</p>') + `
<section class="wrap"><div class="stats"><div><b>26+</b>Anos de Experiência</div><div><b>1200+</b>Linhas entregues</div><div>${I.userOk}Clientes Satisfeitos</div><div>${I.globe}América Latina</div></div>
<div class="story"><span class="badge-y">Começo da Glória</span><h2>A História da BR Robotics</h2>
<p>Em 2000, os engenheiros Helena Marques e Rodrigo Tavares, cansados de ver a fábrica onde trabalhavam depender de robôs importados caros e de manutenção lenta, decidiram criar a própria solução nacional, dando origem à BR Robotics.</p>
<p>Começando numa garagem em Curitiba com R$ 40 mil, a dupla criou o protótipo "Tatu", que após várias falhas conquistou a primeira venda e consolidou a reputação da empresa por robôs resistentes e suporte rápido.</p>
<p>A empresa cresceu por indicação, atendendo diversos setores com robôs adaptados a cada cliente, e em 2008 abriu sua primeira fábrica, além de criar um programa para capacitar operários a trabalhar com os robôs.</p>
<p>Hoje, a BR Robotics é uma das maiores fabricantes de robôs industriais da América Latina, e mantém a garagem original como museu, simbolizando a missão de provar que o Brasil pode criar sua própria tecnologia.</p></div>
<div class="mvv"><div><h3>Missão</h3><p>Desenvolver e fornecer soluções tecnológicas sob medida que aumentem a produtividade e a competitividade da indústria brasileira. Desta forma, fortalecendo o desenvolvimento econômico e industrial do país.</p></div>
<div><h3>Visão</h3><p>Ser reconhecida como referência em máquinas e robótica industrial no Brasil e na América Latina, oferecendo produtos e serviços que geram resultados reais e contribuam com o sucesso de cada parceiro de negócios.</p></div>
<div><h3>Valores</h3><ul><li>Relacionamento</li><li>Respeito</li><li>Integridade</li><li>Confiança</li><li>Excelência</li></ul></div></div></section>`,

  solucoes: () => hero('h-sol', 'solucoes', '<h1>Nossas soluções</h1><p>Para os seus problemas</p>') + `<section class="wrap bands">
${band('b4', `<h2>Treinamento de Equipes</h2><p>Aqui na BR Robotics oferecemos treinamento para os seus funcionários sobre o funcionamento das maquinas</p><ul class="dots"><li>Oferecemos aulas online intuitivas</li><li>Mandamos os nossos melhores treinadores para sua empresa</li></ul>`, 'treinamento', 'Equipe em treinamento na fábrica')}
${band('b5 rev', `<h2>Assistência Técnica</h2><p>Seu equipamento não funciona como devia, não tem o pessoal necessário para manutenção?</p><p>Não se preocupe, a BR Robotics tem funcionarios especializados prontos para te ajudar</p>`, 'assistencia', 'Técnica anotando em prancheta')}</section>`,

  orcamento: () => hero('h-orc', 'orcamento', '<h1 class="one">Orçamento</h1>') + `<section class="wrap form-wrap"><h2 class="ttl">Solicite seu orçamento com a BR Robotics</h2>
<form id="orc" novalidate><div class="f f1"><label for="assunto">Sobre o que você deseja conversar *</label><input id="assunto" name="assunto" class="plain" placeholder="Coloque o assunto..." required/></div>
<div class="row r3">${field('nome', 'Nome *', 'user', 'Digite seu nome')}${field('email', 'E-mail *', 'mail', 'Digite seu e-mail', 'email')}${field('telefone', 'Telefone *', 'wa', '(00) 0000-0000', 'tel')}</div>
<div class="row r2">${field('empresa', 'Empresa *', 'screen', 'Informe a empresa')}${field('cnpj', 'CNPJ da Empresa *', 'doc', 'Informe o CNPJ')}</div>
<div class="row r2">${field('cidade', 'Sua cidade*', 'pin', 'Informe a cidade')}${field('uf', 'Seu UF*', 'pin', 'Informe o UF')}</div>
<p id="msg" role="alert"></p><button class="send" type="submit">Enviar</button></form></section>`
}
function field(id, label, icon, ph, type = 'text') {
  return `<div class="f"><label for="${id}">${label}</label><div class="inp">${I[icon]}<input id="${id}" name="${id}" type="${type}" placeholder="${ph}" required/></div></div>`
}

function bindForm() {
  const f = document.getElementById('orc'); if (!f) return
  const msg = document.getElementById('msg')
  f.addEventListener('submit', e => {
    e.preventDefault(); let ok = true
    f.querySelectorAll('input').forEach(i => { const bad = !i.value.trim(); i.classList.toggle('err', bad); ok = ok && !bad })
    if (!ok) { msg.className = 'bad'; msg.textContent = 'Por favor, preencha todos os campos obrigatórios.'; return }
    if (!/^\S+@\S+\.\S+$/.test(f.email.value)) { f.email.classList.add('err'); msg.className = 'bad'; msg.textContent = 'O e-mail informado é inválido.'; return }
    msg.className = 'ok'; msg.textContent = `Solicitação enviada! Protocolo: ORC-${Date.now().toString().slice(-8)}. Enviamos uma confirmação para o seu e-mail.`
    f.reset()
  })
}

function render() {
  const k = location.hash.replace(/^#\/?/, '')
  document.getElementById('app').innerHTML = header() + `<main>${(pages[k] || pages[''])()}</main>`
  window.scrollTo(0, 0); bindForm()
}
addEventListener('hashchange', render); render()
